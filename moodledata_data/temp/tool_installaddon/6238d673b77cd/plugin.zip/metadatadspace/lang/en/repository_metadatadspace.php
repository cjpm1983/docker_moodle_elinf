<?php
/**
 * @package   repository_metadatadspace
 * @copyright 2016, 
 * Aylen  <abdelrio@uclv.cu>
 * Yoilan <yfimia@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['pluginname'] = "Metadata Dspace Repository ";
$string['configplugin'] = "Dspace Repository settings";
$string['dspace:view'] = 'View the dSpace repository';
$string['dspace_url'] = 'Dspace REST API URL';