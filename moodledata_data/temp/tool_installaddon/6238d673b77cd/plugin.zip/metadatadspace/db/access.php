<?php
/**
 * @package   repository_metadatadspace
 * @copyright 2016, 
 * Aylen  <abdelrio@uclv.cu>
 * Yoilan <yfimia@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
$capabilities = array(
    'repository/metadatadspace:view' => array(
        'captype' => 'read',
        'contextlevel' => CONTEXT_MODULE,
        'archetypes' => array(
            'user' => CAP_ALLOW
        )
    )
);