<?php
/**
 * @package   repository_metadatadspace
 * @copyright 2016, 
 * Aylen  <abdelrio@uclv.cu>
 * Yoilan <yfimia@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2016042600;
$plugin->requires = 2014030200;